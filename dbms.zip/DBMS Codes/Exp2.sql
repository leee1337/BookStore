create database exp2;
use exp2;

CREATE TABLE EMPLOYEE (
    E_id INT,
    E_name VARCHAR(100),
    E_dept VARCHAR(100),
    E_salary FLOAT,
    E_pno VARCHAR(100),
    E_city VARCHAR(100)
);

CREATE VIEW EmployeeView AS
SELECT E_id, E_name, E_dept, E_salary
FROM EMPLOYEE;

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (1, 'John Doe', 'Sales', 5000.00, 'P001', 'New York');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (2, 'Jane Smith', 'HR', 6000.00, 'P002', 'Los Angeles');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (3, 'Michael Johnson', 'Finance', 7000.00, 'P003', 'Chicago');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (4, 'Emily Davis', 'Marketing', 5500.00, 'P004', 'Houston');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (5, 'David Wilson', 'IT', 6500.00, 'P005', 'San Francisco');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (6, 'Sophia Thompson', 'Sales', 5200.00, 'P006', 'Seattle');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (7, 'William Anderson', 'HR', 5900.00, 'P007', 'Boston');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (8, 'Olivia Martinez', 'Finance', 7200.00, 'P008', 'Dallas');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (9, 'James Brown', 'Marketing', 5600.00, 'P009', 'Miami');

INSERT INTO EMPLOYEE (E_id, E_name, E_dept, E_salary, E_pno, E_city)
VALUES (10, 'Emma Clark', 'IT', 6700.00, 'P010', 'Denver');

Select * from EMPLOYEE;
Select * from EmployeeView;
