-- Create the database
CREATE DATABASE exp12;
USE exp12;

-- Create the Customers table
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    city VARCHAR(100),
    age INT
);

-- Insert data into the Customers table
INSERT INTO Customers (customer_id, customer_name, city, age)
VALUES
    (1, 'John', 'New York', 30),
    (2, 'Alice', 'London', 25),
    (3, 'Michael', 'Paris', 35),
    (4, 'Sarah', 'Sydney', 28),
    (5, 'David', 'Berlin', 40);

-- Create the Orders table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

-- Insert data into the Orders table
INSERT INTO Orders (order_id, customer_id, order_date, total_amount)
VALUES
    (1, 1, '2023-06-01', 100.00),
    (2, 2, '2023-06-02', 250.00),
    (3, 3, '2023-06-03', 500.00),
    (4, 4, '2023-06-04', 200.00),
    (5, 5, '2023-06-05', 350.00);

SELECT *
FROM Customers
WHERE age > 30;


SELECT *
FROM Customers
WHERE city = 'London' OR city = 'Paris';
SELECT *
FROM Customers
WHERE city != 'London';


SELECT *
FROM Customers
WHERE customer_name LIKE 'J%';
SELECT *
FROM Customers
WHERE customer_name LIKE '%n';
SELECT *
FROM Customers
WHERE customer_name LIKE '%a%';


