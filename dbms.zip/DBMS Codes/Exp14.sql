create database exp14;
use exp14;

-- Create the Customers table
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    city VARCHAR(100),
    email VARCHAR(100)
);

-- Create the Orders table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

-- Insert sample data into the Customers table
INSERT INTO Customers (customer_id, customer_name, city, email)
VALUES
    (1, 'John', 'New York', 'john@example.com'),
    (2, 'Alice', 'London', 'alice@example.com'),
    (3, 'Michael', 'Paris', 'michael@example.com');

-- Insert sample data into the Orders table
INSERT INTO Orders (order_id, customer_id, order_date, total_amount)
VALUES
    (1, 1, '2023-06-01', 100.00),
    (2, 2, '2023-06-02', 250.00),
    (3, 3, '2023-06-03', 500.00);


-- Create a view to fetch customer details along with their total order count
CREATE VIEW CustomerOrderCount AS
SELECT c.customer_id, c.customer_name, c.city, COUNT(o.order_id) AS order_count
FROM Customers c
LEFT JOIN Orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id;

-- Retrieve data from the view
SELECT * FROM CustomerOrderCount;

-- Insert a new customer into the Customers table
INSERT INTO Customers (customer_id, customer_name, city, email)
VALUES (4, 'Sarah', 'Sydney', 'sarah@example.com');

-- Insert orders for the new customer into the Orders table
INSERT INTO Orders (order_id, customer_id, order_date, total_amount)
VALUES
    (4, 4, '2023-06-04', 150.00),
    (5, 4, '2023-06-05', 200.00);


-- Update the order_count for a customer in the Orders table
UPDATE Orders
SET total_amount = 3
WHERE customer_id = 1;


drop database exp14;
