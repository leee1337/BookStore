create database exp1;
use exp1;

CREATE TABLE RIVERS (
    name VARCHAR(100) NOT NULL,
    length FLOAT,
    outflow VARCHAR(100),
    PRIMARY KEY (name)
);

Select * from RIVERS;

ALTER TABLE RIVERS ADD MaxDepth FLOAT;

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Nile', 6650.00, 'Mediterranean Sea', 8.0);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Amazon', 6992.00, 'Atlantic Ocean', 6.4);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Yangtze', 6300.00, 'East China Sea', 5.0);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Mississippi', 6275.00, 'Gulf of Mexico', 7.3);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Yenisei', 5545.00, 'Kara Sea', 6.4);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Yellow River', 5464.00, 'Bohai Sea', 5.0);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Congo', 4700.00, 'Atlantic Ocean', 7.0);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Mackenzie', 4241.00, 'Beaufort Sea', 2.8);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Volga', 3690.00, 'Caspian Sea', 3.0);

INSERT INTO RIVERS (name, length, outflow, MaxDepth)
VALUES ('Danube', 2850.00, 'Black Sea', 2.0);

