create database exp6;
use exp6;

CREATE TABLE S_customer (
    name VARCHAR(100),
    credit_rating INT,
    sales_rep_id INT
);

INSERT INTO S_customer (name, credit_rating, sales_rep_id)
VALUES
    ('John Doe', 7, 4232),
    ('Jane Smith', 6, 4232),
    ('Michael Johnson', 8, 4232),
    ('Emily Davis', 9, 4232),
    ('David Wilson', 5, 4232),
    ('Sophia Thompson', 7, 4232),
    ('William Anderson', 6, 4232),
    ('Olivia Martinez', 8, 4232),
    ('James Brown', 9, 4232),
    ('Emma Clark', 5, 4232);
    
DELIMITER //

CREATE PROCEDURE GetAllCustomers()
BEGIN
    SELECT * FROM S_customer;
END //

DELIMITER ;

CALL GetAllCustomers();

truncate  table S_customer;

