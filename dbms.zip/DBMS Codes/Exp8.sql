create database exp8;
use exp8;

CREATE TABLE employees (
    emp_id INT PRIMARY KEY,
    name VARCHAR(100),
    department VARCHAR(100),
    role VARCHAR(100),
    salary DECIMAL(10,2),
    joining_date DATE
);

INSERT INTO employees (emp_id, name, department, role, salary, joining_date)
VALUES
    (1, 'John Doe', 'HR', 'Manager', 6000.00, '2022-01-01'),
    (2, 'Jane Smith', 'IT', 'Developer', 5500.00, '2022-02-15'),
    (3, 'Michael Johnson', 'Finance', 'Accountant', 4500.00, '2022-03-10'),
    (4, 'Emily Davis', 'Marketing', 'Sales Representative', 7000.00, '2022-04-20'),
    (5, 'David Wilson', 'Operations', 'Supervisor', 5800.00, '2022-05-05');
    
DELIMITER //

CREATE TRIGGER CheckEmployeeSalary
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    IF NEW.salary < 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Salary cannot be negative.';
    END IF;
END //
DELIMITER ;

INSERT INTO employees (emp_id, name, department, role, salary, joining_date)
VALUES (1, 'Sham', 'Finance', 'Accountant', -500.00, '2023-06-01');
-- Above query will not execute because the trigger will not allow to execute  



