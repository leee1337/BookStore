create database exp4;
use exp4;

CREATE TABLE customer (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    phone_number VARCHAR(100),
    city VARCHAR(100)
);

INSERT INTO customer (id, name, phone_number, city)
VALUES
    (295, 'John Doe', '1234567890', 'Mumbai'),
    (296, 'Jane Smith', '9876543210', 'Delhi'),
    (297, 'Michael Johnson', '0123456789', 'Bangalore'),
    (298, 'Emily Davis', '9870123456', 'Chennai'),
    (299, 'David Wilson', '6543210987', 'Hyderabad'),
    (300, 'Sophia Thompson', '7890123456', 'Kolkata'),
    (301, 'William Anderson', '0129876543', 'Pune'),
    (302, 'Olivia Martinez', '5432109876', 'Ahmedabad'),
    (303, 'James Brown', '9012345678', 'Jaipur'),
    (304, 'Emma Clark', '8765432109', 'Surat'),
    (305, 'Liam Taylor', '2345678901', 'Lucknow'),
    (306, 'Ava Davis', '8901234567', 'Kanpur'),
    (307, 'Noah Miller', '3456789012', 'Nagpur'),
    (308, 'Isabella Wilson', '6789012345', 'Indore'),
    (309, 'Mason Thompson', '9012345678', 'Patna'),
    (310, 'Sophia Anderson', '0123456789', 'Bhopal'),
    (311, 'Logan Clark', '4567890123', 'Coimbatore'),
    (312, 'Lucas Davis', '7890123456', 'Vadodara'),
    (313, 'Oliver Thomas', '0123456789', 'Ludhiana'),
    (314, 'Emma Wilson', '3456789012', 'Agra');





SELECT id, name, phone_number
FROM customer
WHERE id BETWEEN 303 AND 306;

SELECT id, name, phone_number
FROM customer
WHERE id > 300 AND city = 'Pune';

-- Drop table customer;
-- truncate table customer;
