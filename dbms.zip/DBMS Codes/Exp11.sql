create database exp11;
use exp11;


CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    email VARCHAR(100),
    address VARCHAR(100)
);
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    total_amount DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    price DECIMAL(10,2)
);

-- Inserting data into the Customers table
INSERT INTO Customers (customer_id, customer_name, email, address)
VALUES (1, 'Rajesh Kumar', 'rajesh@example.com', '123 ABC Street, Mumbai'),
       (2, 'Neha Sharma', 'neha@example.com', '456 XYZ Road, Delhi'),
       (3, 'Sandeep Patel', 'sandeep@example.com', '789 PQR Avenue, Bangalore');

-- Inserting data into the Orders table
INSERT INTO Orders (order_id, customer_id, order_date, total_amount)
VALUES (1, 1, '2023-06-01', 500.00),
       (2, 2, '2023-06-02', 750.00),
       (3, 3, '2023-06-03', 1000.00);

-- Inserting data into the Products table
INSERT INTO Products (product_id, product_name, price)
VALUES (1, 'Mobile Phone', 9999.99),
       (2, 'Laptop', 34999.99),
       (3, 'Smart TV', 25999.99);
       
