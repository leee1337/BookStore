-- Create the database
CREATE DATABASE exp13;
USE exp13;

-- Create the Employees table
CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(100),
    department VARCHAR(100),
    salary DECIMAL(10, 2),
    hire_date DATE
);

-- Insert data into the Employees table
INSERT INTO Employees (employee_id, employee_name, department, salary, hire_date)
VALUES
    (1, 'John', 'Sales', 5000.00, '2020-01-01'),
    (2, 'Alice', 'HR', 6000.00, '2020-02-01'),
    (3, 'Michael', 'Marketing', 4500.00, '2019-12-01'),
    (4, 'Sarah', 'Finance', 5500.00, '2020-03-01'),
    (5, 'David', 'IT', 7000.00, '2020-01-15');

-- Perform SQL queries using arithmetic operations, built-in functions, and aggregate functions

-- Arithmetic Operations and Built-in Functions

-- Calculate the total salary of all employees
SELECT SUM(salary) AS total_salary
FROM Employees;

-- Calculate the average salary of employees in the Sales department
SELECT AVG(salary) AS average_salary
FROM Employees
WHERE department = 'Sales';

-- Calculate the total salary of employees hired before 2020
SELECT SUM(salary) AS total_salary
FROM Employees
WHERE hire_date < '2020-01-01';

-- Retrieve employee names and their salaries with a 10% bonus
SELECT employee_name, salary * 1.1 AS new_salary
FROM Employees;

-- Aggregate Functions

-- Retrieve the maximum salary among all employees
SELECT MAX(salary) AS max_salary
FROM Employees;

-- Retrieve the minimum salary among all employees
SELECT MIN(salary) AS min_salary
FROM Employees;

-- Retrieve the number of employees in each department
SELECT department, COUNT(*) AS employee_count
FROM Employees
GROUP BY department;

-- Retrieve the average salary of employees for each department
SELECT department, AVG(salary) AS average_salary
FROM Employees
GROUP BY department;
