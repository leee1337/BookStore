create database exp7;
use exp7;

CREATE TABLE customer (
    name VARCHAR(100),
    credit_rating INT,
    sales_rep_id INT
);

INSERT INTO customer (name, credit_rating, sales_rep_id)
VALUES
    ('John Doe', 7, 4232),
    ('Jane Smith', 6, 4232),
    ('Michael Johnson', 8, 4232),
    ('Emily Davis', 9, 4232),
    ('David Wilson', 5, 4232),
    ('Sophia Thompson', 7, 4232),
    ('William Anderson', 6, 4232),
    ('Olivia Martinez', 8, 4232),
    ('James Brown', 9, 4232),
    ('Emma Clark', 5, 4232);
    
DELIMITER //

CREATE PROCEDURE InsertCustomer(
    IN customer_name VARCHAR(100),
    IN customer_credit_rating INT,
    IN customer_sales_rep_id INT
)
BEGIN
    INSERT INTO customer (name, credit_rating, sales_rep_id)
    VALUES (customer_name, customer_credit_rating, customer_sales_rep_id);
END //

DELIMITER ;

CALL InsertCustomer('Sham', 6, 4032);

select * from customer;

    


truncate  table customer;

