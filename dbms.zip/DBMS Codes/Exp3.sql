create database exp3;
use exp3;

CREATE TABLE S_customer (
    name VARCHAR(100),
    credit_rating INT,
    sales_rep_id INT
);

INSERT INTO S_customer (name, credit_rating, sales_rep_id)
VALUES
    ('John Doe', 7, 4232),
    ('Jane Smith', 6, 4232),
    ('Michael Johnson', 8, 4232),
    ('Emily Davis', 9, 4232),
    ('David Wilson', 5, 4232),
    ('Sophia Thompson', 7, 4232),
    ('William Anderson', 6, 4232),
    ('Olivia Martinez', 8, 4232),
    ('James Brown', 9, 4232),
    ('Emma Clark', 5, 4232);

SELECT name, credit_rating, sales_rep_id
FROM S_customer
WHERE credit_rating > 5 AND sales_rep_id = 4232;
