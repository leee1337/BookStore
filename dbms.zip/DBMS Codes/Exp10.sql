create database exp10;
use exp10;

CREATE TABLE employees (
    emp_id INT PRIMARY KEY,
    name VARCHAR(100),
    department VARCHAR(100),
    role VARCHAR(100),
    salary DECIMAL(10,2),
    joining_date DATE
);

INSERT INTO employees (emp_id, name, department, role, salary, joining_date)
VALUES
    (1, 'John Doe', 'HR', 'Manager', 6000.00, '2022-01-01'),
    (2, 'Jane Smith', 'IT', 'Developer', 5500.00, '2022-02-15'),
    (3, 'Michael Johnson', 'Finance', 'Accountant', 4500.00, '2022-03-10'),
    (4, 'Emily Davis', 'Marketing', 'Sales Representative', 7000.00, '2022-04-20'),
    (5, 'David Wilson', 'Operations', 'Supervisor', 5800.00, '2022-05-05');
    
CREATE VIEW EmployeeNameJoiningView AS
SELECT name, joining_date FROM employees;

SELECT * FROM EmployeeNameJoiningView;
