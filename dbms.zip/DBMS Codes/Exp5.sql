create database exp5;
use exp5;

CREATE TABLE student (
    student_id INT PRIMARY KEY,
    name VARCHAR(100),
    math_marks INT,
    attendance INT,
    dbms_marks INT
);

INSERT INTO student (student_id, name, math_marks, attendance, dbms_marks)
VALUES
    (1, 'Ravi Kumar', 80, 45, 70),
    (2, 'Priya Singh', 90, 60, 85),
    (3, 'Amit Patel', 75, 75, 80),
    (4, 'Deepika Sharma', 85, 65, 75),
    (5, 'Rahul Gupta', 95, 35, 90),
    (6, 'Sneha Verma', 70, 55, 80),
    (7, 'Vikram Singh', 88, 40, 65),
    (8, 'Kiran Reddy', 92, 50, 70),
    (9, 'Pooja Mehta', 78, 80, 75),
    (10, 'Ajay Kumar', 82, 85, 60),
    (11, 'Anjali Sharma', 88, 45, 70),
    (12, 'Rajesh Gupta', 85, 50, 80),
    (13, 'Neha Kapoor', 90, 65, 75),
    (14, 'Suresh Kumar', 76, 75, 85),
    (15, 'Swati Gupta', 85, 35, 90),
    (16, 'Arun Patel', 72, 55, 75),
    (17, 'Mita Verma', 83, 60, 65),
    (18, 'Sanjay Sharma', 88, 40, 70),
    (19, 'Sarika Reddy', 95, 50, 75),
    (20, 'Ramesh Mehta', 82, 70, 60);

    
truncate table student;

SELECT *
FROM student
WHERE math_marks = (SELECT MAX(math_marks) FROM student);

SELECT *
FROM student
WHERE attendance = (SELECT MIN(attendance) FROM student);

SELECT COUNT(*) AS total_students
FROM student;

SELECT AVG(dbms_marks) AS average_dbms_marks
FROM student;


